#!/usr/bin/env python3
"""Збирає index.html із template.html + routes.json (одне джерело даних для каталогу та Schema.org)."""
import json, pathlib, sys
root = pathlib.Path(__file__).resolve().parent
out = pathlib.Path(sys.argv[1]) if len(sys.argv) > 1 else root / 'index.html'
routes = json.loads((root / 'routes.json').read_text(encoding='utf-8'))
COUNTRY_NAMES = {'it': 'Italy', 'fr': 'France', 'cz': 'Czechia', 'de': 'Germany', 'pl': 'Poland', 'at': 'Austria', 'es': 'Spain', 'gb': 'United Kingdom'}
org = {"@type": "Organization", "@id": "https://uaguides.com/#organization", "name": "ГС «Всеукраїнська асоціація гідів»",
       "alternateName": ["Ukrainian Tourist Guides Association", "UTGA", "ВАГ"], "url": "https://uaguides.com/",
       "identifier": {"@type": "PropertyValue", "propertyID": "ЄДРПОУ", "value": "40497218"},
       "email": "tourguidesua@gmail.com", "telephone": "+380509216727",
       "address": {"@type": "PostalAddress", "addressLocality": "Київ", "addressCountry": "UA"},
       "memberOf": [{"@type": "Organization", "name": "European Federation of Tourist Guide Associations (FEG)"},
                    {"@type": "Organization", "name": "World Federation of Tourist Guide Associations (WFTGA)"}]}
items = []
for i, r in enumerate(routes, 1):
    trip = {"@type": "TouristTrip", "@id": f"https://tours.uaguides.com/#{r['id']}", "name": r['title']['uk'],
            "description": r['summary']['uk'], "inLanguage": "uk", "touristType": r['theme'],
            "provider": {"@id": "https://uaguides.com/#organization"},
            "itinerary": {"@type": "ItemList", "itemListElement": [
                {"@type": "ListItem", "position": n, "item": {"@type": "TouristAttraction", "name": s['uk']}} for n, s in enumerate(r['stops'], 1)]}}
    if r['img']:
        trip["image"] = f"https://images.unsplash.com/{r['img']}?auto=format&fit=crop&w=1200&q=70"
    if r['region'] == 'eu':
        trip["contentLocation"] = {"@type": "City", "name": r['city']['en'], "containedInPlace": {"@type": "Country", "name": COUNTRY_NAMES[r['country']]}}
    else:
        trip["contentLocation"] = {"@type": "Place", "name": r['city']['en'], "containedInPlace": {"@type": "Country", "name": "Ukraine"}}
    items.append({"@type": "ListItem", "position": i, "item": trip})
jsonld = {"@context": "https://schema.org", "@graph": [org, {"@type": "WebSite", "name": "Гіди ВАГ за кордоном", "url": "https://tours.uaguides.com/", "inLanguage": ["uk", "en"], "publisher": {"@id": "https://uaguides.com/#organization"}},
          {"@type": "ItemList", "name": "Україномовні екскурсії ВАГ", "numberOfItems": len(items), "itemListElement": items}]}
safe = lambda o: json.dumps(o, ensure_ascii=False, separators=(',', ':')).replace('</', '<\\/')
html = (root / 'template.html').read_text(encoding='utf-8').replace('{{JSONLD}}', safe(jsonld)).replace('{{ROUTES}}', safe(routes))
assert '{{' not in html
out.write_text(html, encoding='utf-8')
print(f'{out}: {len(html):,} bytes, {len(routes)} routes')
